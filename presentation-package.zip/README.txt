AI 與人類駕駛，誰更安全？｜14頁離線簡報

解壓縮後，以桌面Edge或Chrome開啟 presentation/index.html。
下一頁：右方向鍵、PageDown或空白。上一頁：左方向鍵或PageUp。
第一頁／最後一頁：Home／End。換頁鍵不顯示於畫面。
左下資料來源可開啟raw/papers中的原始研究PDF。
請保留presentation與raw資料夾的相對位置；本機字型與授權位於presentation/assets。
本版沒有控制列、附錄、講稿或列印PDF功能。
